from tkinter import *
from tkinter import messagebox

def addData():

    id = t1.get()
    name = t2.get()
    salary = t3.get()

    data = id +','+name+','+salary
    list.insert(END,data)
    t1.delete(0,END)
    t2.delete(0,END)
    t3.delete(0,END)
    t1.focus()

def selectData():
    data =list.get(ACTIVE)
   

    data=data.split(',')
    t1.insert(0, data[0])
    t2.insert(0, data[1])
    t3.insert(0, data[2])
    # returns the index of the record selected
    index.set(list.curselection()[0])

def updateData():
    # delete the original record
    i = index.get()
    list.delete(i)

    id = t1.get()
    name= t2.get()
    salary = t3.get()

    data = id+','+name+','+salary
    # insert the updated record
    list.insert(i,data)
    
    # make textbox empty
  

def deleteData():
    list.delete(ACTIVE)

if(__name__ =="__main__"):
    window = Tk()
    window.configure(background='pink') 
    index = IntVar()
    frame1 = Frame(window,highlightthickness=1,highlightbackground="black",padx=30)
    frame2 = Frame(window,highlightthickness=1,highlightbackground="black",pady=20)
    frame3 = Frame(window,highlightthickness=1,highlightbackground="black",pady=10)


    l1 = Label(frame1, text="Enter id: ")
    l2 = Label(frame1, text="Enter name: ")
    l3 = Label(frame1, text="Enter salary: ")

    t1= Entry(frame1)
    t2= Entry(frame1)
    t3= Entry(frame1)

    l1.grid(row=1,column=1)
    t1.grid(row=1, column=2)

    l2.grid(row=2,column=1)
    t2.grid(row=2,column=2)

    l3.grid(row=3,column=1)
    t3.grid(row=3,column=2)


    btn1= Button(frame2, text="Add",command=addData)
    btn2 = Button(frame2, text="Select",command=selectData)
    btn3 = Button(frame2, text="Update",command=updateData)
    btn4 = Button(frame2, text="Delete",command=deleteData)

    btn1.grid(row=1, column=1)
    btn2.grid(row=1, column=2)
    btn3.grid(row=1, column=3)
    btn4.grid(row=1, column=4)


    
    scbar = Scrollbar(frame3)

    scbar.pack(side=RIGHT,fill="y")
    list = Listbox(frame3,yscrollcommand=scbar.set)
    scbar.config(command=list.yview)
    list.pack()
    frame1.pack()
    frame2.pack()
    frame3.pack()

    window.geometry("300x300")
    window.mainloop()