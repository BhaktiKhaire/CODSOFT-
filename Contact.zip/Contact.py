# Storing name, phone number, email, and address
class contact:
    #Constructor
    def __init__(self,id,name,phone,email,address):
       
        self.id=id
        self.name = name
        self.phone = phone
        self.email = email
        self.address = address
       
    def getId(self):
        return self.id
    
    def setId(self,id):
        self.id = id
        
    def getName(self):
        return self.name
    
    def setName(self,name):
        self.name = name
    
    def getPhone(self):
        return self.phone
    def setPhone(self,phone):
        self.phone = phone
    
    def getEmail(self):
        return self.email
    def setEmail(self,email):
        self.email = email

    def getAddress(self):
        return self.address
    def setAddress(self,address):
        self.address = address

    

    @staticmethod
    def generate_headings():
        return "ID\tName\tPhone\tEmail\tAddress\n"

    def __str__(self):
        return str(self.id) + "\t" + self.name + "\t" + str(self.phone) + "\t" + self.email + "\t" + self.address + "\n"

   # def __str__(self):
        
        #return str(self.id)+"   "+self.name +"     "+str(self.phone)+"    "+str(self.email)+"        "+self.address+"\n"