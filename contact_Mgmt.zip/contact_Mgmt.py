#Contact Information: Store name, phone number, email, and address for each contact.
#Add Contact: Allow users to add new contacts with their details.
#View Contact List: Display a list of all saved contacts with names and phone numbers.
#Search Contact: Implement a search function to find contacts by name or phone number.
#Update Contact: Enable users to update contact details.
#Delete Contact: Provide an option to delete a contact.
#User Interface: Design a user-friendly interface for easy interaction


import os
class Contact_mgmt:
    
    def add_details(self, e):
     fp = open("info.txt", 'a')
     fp.write(str(e))
     fp.close()  # Close the file after all operations



    def view_details(self):
        if(os.path.exists("info.txt")):  #file exists or not
            with open("info.txt", 'r') as fp:  #File open & close
                for e in fp:  #line by line read data
                    print(e)
        else:
            print("File does not exist")

    def search_details(self,id):
        with open("info.txt", "r") as fp:
            # e: ek employee ka data 101,Anu, 10000
            # 102
         for e in fp:
                try:
                    e.index(str(id),0,3)
                    print(e)
                    break
                except ValueError:
                    pass
         else:
                print("contact not found")

    def delete_details(self, id):
        # read file & check if id present
        found=False
        with open("info.txt",'r') as fp:
            details = []
            for e in fp:
               
                # If id match do nothing
                try:
                    e.index(str(id),0,3)                    
                except ValueError:
                    details.append(e)
                else:
                    found= True
            
                    # record present

        # write data back to file
        if(found == True):
            with open("info.txt","w") as fp:
                for x in details:
                    fp.write(x)
                
        else:
            print("Record not found")
   
            
   

            #For Admin login

    def addT(self,e):
         fp= open("data.txt",'a')
         fp.write(str(e))
         print("Details added succesfully")
         fp.close()
    
     
    def Update_details(self,id):
        found=False
        list1=[]  #container to store founded value
    
        with open("info.txt",'r') as fp:
           # list1=[]  #container to store founded value
            for e in fp:
                try:
                    e.index (str(id),0,3)
                    
                   
                   
                except:
                   list1.append(e)
                     
                    #if record not match
                    
            else:
                    ch = input("What do you want to update:(name/phone/address/email): ")
                    if(ch=='name'):
                        name=input("Enter name to replace:")
                        split_data = e.split(',')  #to make the list of data to update specific record
            
                        split_data[6]=name 
                        e=','.join(split_data) #join fun use to combine details and separate by',' or 
                        

                        
                        #another thing to convert list into data we use join

                        list1.append(e)
                        found=True
                        if(found==True):
                            with open ("info.txt",'w') as fp:
                                for name in list1:
                                    fp.write(name)
                        else:
                            print("Data not found")


                    elif(ch=='phone'):
                        phone=int(input("Enter phone number to update:"))
                        split_data = e.split(',')  #to make the list of data to update specific record
                        split_data[2]=phone 
                        e=','.join(split_data) #join fun use to combine details and separate by',' or 
                        
                        #another thing to convert list into data we use join

                        list1.append(e)
                        found=True
                        if(found==True):
                            with open ("info.txt",'w') as fp:
                                for phone in list1:
                                    fp.write(phone)
                        else:
                            print("Data not found")


                    elif(ch=='address'):
                        address=input("Enter address to update:")
                        split_data = e.split(',')  #to make the list of data to update specific record
                        split_data[3]=address
                        e=','.join(split_data) #join fun use to combine details and separate by',' or 
                        
                        #another thing to convert list into data we use join

                        list1.append(e)
                        found=True
                        if(found==True):
                            with open ("info.txt",'w') as fp:
                                for address in list1:
                                    fp.write(address)
                        else:
                            print("Data not found")

                            
                    elif(ch=='email'):
                        email=input("Enter email:")

                        split_data = e.split(',')  #to make the list of data to update specific record
                        split_data[4]=email 
                        e=','.join(split_data) #join fun use to combine details and separate by',' or 
                        
                        #another thing to convert list into data we use join

                        list1.append(e)
                        found=True
                        if(found==True):
                            with open ("info.txt",'w') as fp:
                                for email in list1:
                                    fp.write(email)
                        else:
                            print("Data not found")


            

