from Contact import contact
from contact_Mgmt import Contact_mgmt

if(__name__ =="__main__"):

    m=Contact_mgmt()
 
    ch2=0
    while(ch2 !=10):
                print('''
                       1.Add Contact Details
                       2.Search  Details
                       3.Delete Details
                       4.Update Details
                       5.View All details
                       6.Exit
                      ''')
                ch2=int(input("Enter Your Choice:"))
        
                if(ch2==1):
                      while True:  # Infinite loop until user inputs 'N'
                            id = int(input("Enter id:"))
                            name = input("Enter name:")
                            phone = int(input("Enter phone number:"))
                            address = input("Enter address:")
                            email = input("Enter email:")
                            e = contact(id, name, phone, address, email)
                            m.add_details(e)
                            print("Details added successfully")
                            k = input("Do you want to continue(Y/N): ")
                            if k.upper() != 'Y':
                             break  # Exit the loop if user inputs 'N'

                   
                    #k=input("Do you want to continue(Y/N):")
                    #if(k=='Y'):
                         # m.add_details(e)
                   # else:
                          #1 break
                    
                
                elif(ch2==2):
                       id=int(input("Enter id to search:"))
                       m.search_details(id)
                       
                elif(ch2==3):
                       id=int(input("Enter id to delete:"))
                       m.delete_details(id)
                       print("details deleted successfully...")
                       
                elif(ch2==4):
                       m.view_details()
                       id=input("Enter id to update the feild:")
                       m.Update_details(id)
                       print("Details updated successfully....")
                       
                elif(ch2==5):
                       m.view_details()
                      
                elif(ch2==6):
                       print("Process Exited")
                       break

                        